
## About Laravel

Laravel Multi Auth with Breeze and Admin LTE 3

## Features

- Admin CRUD
- USER CRUD
- [Admin LTE](https://adminlte.io/) 3 Change Theme Option

## Instructions
Download or clone repository

```
composer update
```

## License
 The Laravel framework is open-sourced software licensed under the [MIT license](https://opensource.org/licenses/MIT).